/*如果这段代码好用，那它是葛嘉明写的。
如果不好用，我不知道是谁写的。*/


// /*头部菜单*/
//   $(function(){
//      $(window).scroll(function(){
//       if ( $(window).scrollTop() > 0 ) {
//           $('.header').addClass('scroll');
//       } else {
//           $('.header').removeClass('scroll');
//       }
//     });
//   });

/*右边悬浮滑动*/
  $(document).ready(function(){
        $("#phone").hover(function() {
                $(this).find("em").animate({opacity: "show"}, "slow");
        }, function() {
                $(this).find("em").animate({opacity: "hide"}, "fast");
        });

        $("#qr").hover(function() {
                $(this).find("div").animate({opacity: "show"}, "slow");
        }, function() {
                $(this).find("div").animate({opacity: "hide"}, "fast");
        });
  });

//   $(function(){
//     $(window).scroll(function(){
//       if ( $(window).scrollTop() > 0 ) {
//           $('.nav_right').css('display','block');
//       } else {
//           $('.nav_right').css('display','none');
//       }
//     });
//   });


/*提示框*/
function showTips(txt,time,status)
{
	var htmlCon = '';
	if(txt != ''){
		if(status != 0 && status != undefined){
			htmlCon = '<div class="tipsBox" style="width:220px;padding:10px;background-color:#4AAF33;border-radius:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;color:#fff;box-shadow:0 0 3px #ddd inset;-webkit-box-shadow: 0 0 3px #ddd inset;text-align:center;position:fixed;top:25%;left:50%;z-index:999999;margin-left:-120px;"><img src="/assets/images/ok.png" style="vertical-align: middle;margin-right:5px;" alt="OK，"/>'+txt+'</div>';
		}else{
			htmlCon = '<div class="tipsBox" style="width:220px;padding:10px;background-color:#D84C31;border-radius:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;color:#fff;box-shadow:0 0 3px #ddd inset;-webkit-box-shadow: 0 0 3px #ddd inset;text-align:center;position:fixed;top:25%;left:50%;z-index:999999;margin-left:-120px;"><img src="/assets/images/err.png" style="vertical-align: middle;margin-right:5px;" alt="Error，"/>'+txt+'</div>';
		}
		$('body').prepend(htmlCon);
		if(time == '' || time == undefined){
			time = 1500;
		}
		setTimeout(function(){ $('.tipsBox').remove(); },time);
	}
}


document.write("<script src='/assets/js/core/crypto-js.js'></script>");
var aseKey = "132456abcde"
var secret = ['password'];
var storage = {
  setItem: function (name, value) {
    localStorage.setItem(name, secret.indexOf(name)>-1?CryptoJS.AES.encrypt(value, aseKey).toString():value)
  },
  getItem: function (name) {
	return secret.indexOf(name)>-1?CryptoJS.AES.decrypt(localStorage.getItem(name), aseKey).toString(CryptoJS.enc.Utf8)||localStorage.getItem(name):localStorage.getItem(name)
  },
  removeItem: function (name) {
    localStorage.removeItem(name)
  },
  clear:function () {
    localStorage.clear();
  }
};