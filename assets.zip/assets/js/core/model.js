// var http_url = "http://192.168.2.116:9501";
// var http_url = "http://192.168.2.116:52711";
// var http_url = "http://223.112.159.106:9501";
// var http_url = "https://swoole.u-jy.cn";
// var http_url = "http://127.0.0.1:9501";
// var http_url="http://101.37.195.10:9501";
// var http_url="http://192.168.24.128:9501";
// var http_url = "https://releaseswoole.u-jy.cn";
document.write("<script type='text/javascript' src='/http_url.js'></script>");
var md = {
	innerW: document.documentElement.clientWidth, //当前网页可见区域宽度
	innerH: document.documentElement.clientHeight, //当前网页可见区域高度
	scrollH: "",

    removeData: function(modal,files){
        $("#"+modal+"").find('input:not(.noClear)').val('');
        $("#"+modal+"").find('textarea').val('');
        $("#"+modal+"").find('select').val('0');
        $("#"+modal+"").find("#"+files+"").find("li").not("#li_upload").remove();
    },

    mask_on: function() { //自定义遮罩开启
        this.scrollH = document.body.scrollHeight;
        $("body").append('<div class="md_mask" id="md_mask"></div>');
        $("#md_mask").css("height", this.scrollH);
    },
    mask_off: function() { //自定义遮罩关闭
        $("#md_mask").remove();
    },
    confirm: function(text_head, text_info, callback_yes, callback_no) { //自定义确定取消框小
        this.scrollH = document.body.scrollHeight;
        $("body").append('<div class="md_tanchu_mask" id="md_tanchu_mask"></div>');
        $("body").append('<div class="md_tanchu_del" id="md_tanchu_del"><div class="mb_tanchu_head mb_color_green">' + text_head + '<img src="/assets/images/clo.png" class="right mb_hover mb_margint10 mb_marginr10" id="md_close"/></div><p style="margin-top:20px;">' + text_info + '</p><div class="mb_tanchu_res"><a class="md_tanchu_yes" id="md_tanchu_yes">确定</a><a class="md_tanchu_no" id="md_tanchu_no">取消</a></div></div>');
        $("#md_tanchu_mask").css("height", this.scrollH);
        $("#md_tanchu_del").css({"left":"50%","marginLeft":"-200px","top":"50%","transform": "translateY(-50%)"});
        $("#md_tanchu_yes").click(function() {
            if(callback_yes() == undefined) {
                $("#md_tanchu_mask").remove();
                $("#md_tanchu_del").remove();
            }
        });
        $("#md_tanchu_no").click(function() {
            callback_no();
            $("#md_tanchu_mask").remove();
            $("#md_tanchu_del").remove();
        });
        $("#md_close").click(function() {
            $("#md_tanchu_mask").remove();
            $("#md_tanchu_del").remove();
        });
    },
    confirmRevise: function(width, text_head, text_info, callback_yes, callback_no, callback_verify) { //物品审核弹框  批准，驳回，修改批准
        this.scrollH = document.body.scrollHeight;
        $("body").append('<div class="md_tanchu_mask" id="md_tanchu_mask"></div>');
        $("body").append('<div class="md_tanchu_del" id="md_tanchu_del"><div class="mb_tanchu_head mb_color_green" style="margin-bottom:15px;">' + text_head + '<img src="/assets/images/clo.png" class="right mb_hover mb_margint10 mb_marginr10" id="md_close"/></div><div style="width:90%;margin:20px auto;">' + text_info + '</div><div class="mb_tanchu_res"><a class="md_tanchu_yes" id="md_tanchu_yes">批准</a><a class="md_tanchu_no" id="md_tanchu_revise">修改批准</a><a class="md_tanchu_no mb_marginl40" id="md_tanchu_no">驳回</a></div></div>');
        $("#md_tanchu_del").css("width", width + "px");
        $("#md_tanchu_mask").css("height", this.scrollH);
        $("#md_tanchu_del").css("left", (this.innerW - $("#md_tanchu_del").width()) / 2 + "px").css("top", "30px");
        $("#md_tanchu_yes").click(function() {
            if(callback_yes() == undefined) {
                $("#md_tanchu_mask").remove();
                $("#md_tanchu_del").remove();
            }		})
        $("#md_tanchu_no").click(function() {
            if(callback_no() == undefined) {
                $("#md_tanchu_mask").remove();
                $("#md_tanchu_del").remove();
            };
        })
        $("#md_tanchu_revise").click(function() {
            if(callback_verify() == undefined) {
                $("#md_tanchu_mask").remove();
                $("#md_tanchu_del").remove();
            };
        })
        $("#md_close").click(function() {
            $("#md_tanchu_mask").remove();
            $("#md_tanchu_del").remove();
        })
    },
    confirmSelect: function(width, text_head, text_info, callback_yes, callback_no) { //自定义确定取消框大
        this.scrollH = document.body.scrollHeight;
        $("body").append('<div class="md_tanchu_mask" id="md_tanchu_mask"></div>');
        $("body").append('<div class="md_tanchu_del" id="md_tanchu_del"><div class="mb_tanchu_head mb_color_green" style="margin-bottom:15px;">' + text_head + '<img src="/assets/images/clo.png" class="right mb_hover mb_margint10 mb_marginr10" id="md_close"/></div><div style="width:90%;margin:0 auto;">' + text_info + '</div><div class="mb_tanchu_res"><a class="md_tanchu_yes" id="md_tanchu_yes">确定</a><a class="md_tanchu_no" id="md_tanchu_no">取消</a></div></div>');
        $("#md_tanchu_del").css("width", width + "px");
        $("#md_tanchu_mask").css("height", this.scrollH);
        $("#md_tanchu_del").css("left", (this.innerW - $("#md_tanchu_del").width()) / 2 + "px").css("top", "30px");
        $("#md_tanchu_yes").click(function() {
            if(callback_yes() == undefined) {
                $("#md_tanchu_mask").remove();
                $("#md_tanchu_del").remove();
            }
        })
        $("#md_tanchu_no").click(function() {
            callback_no();
            $("#md_tanchu_mask").remove();
            $("#md_tanchu_del").remove();
        })
        $("#md_close").click(function() {
            $("#md_tanchu_mask").remove();
            $("#md_tanchu_del").remove();
        });
    },
    getCookie:function(c_name){
        if (document.cookie.length>0){
            c_start=document.cookie.indexOf(c_name + "=")
            if (c_start!=-1){
                c_start=c_start + c_name.length+1
                c_end=document.cookie.indexOf(";",c_start)
                if (c_end==-1) c_end=document.cookie.length
                return unescape(document.cookie.substring(c_start,c_end))
            }
        }
        return ""
    },
    ajax: function(type, url, data, success_callback) {
        $.ajax({
            type: type,
            url: url,
            data: data,
            timeout: 10000,
            async: true,
            dataType:"json",
            headers : { 'ujy-session':md.getCookie('ujy_session')},
            success: function(res){
                if(!res.code){
                    success_callback(res)
                }else{
                    if(res.code == '20000'){
                        showTips(res.msg);
                        window.location.href='/login';
                    }else if(res.code == '20004'){
                        showTips(res.msg);
                        window.location.href='/login';
                    }else{
                        showTips(res.msg);
                    }
                }
            },
            error: function(xhr){
                if(xhr.responseJSON){
                    if(xhr.responseJSON.code == '20006'){
                        showTips(xhr.responseJSON.msg);
                        window.location.href='/login';
                    }else if(xhr.responseJSON.code == '20009'){
                        showTips(xhr.responseJSON.msg);
                        window.location.href='/login';
                    }else{
                        showTips(xhr.responseJSON.msg);
                        md.load_off();
                    }
                }else{
                    showTips('服务器错误:'+[xhr.status]+'')
                    md.load_off();
                }
            } ,
            complete:function(XMLHttpRequest,textStatus){
                if(textStatus=='timeout'){
                    var xmlhttp = window.XMLHttpRequest ? new window.XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHttp");
                    xmlhttp.abort();
                    showTips('网络超时,请重试');
                    md.load_off();
                }
            }
        });
    },
    load_on: function(){
        this.scrollH = document.body.scrollHeight; //当前网页可见区域高度
        $("body").append('<div id="scrollH" style="position:absolute;top: 0;left: 0;width: 100%;z-index:9999;background-color:rgba(0,0,0,0.3)">'
            +'<div style="position:fixed;top:50%;left:50%;font-weight:600;"><i class="icon-spinner icon-spin icon-4x"></i><p style="margin-left:-50px">加载中，请耐心等待</p></div></div>');
        $("#scrollH").css("height", this.scrollH);
    },
    load_off: function(){
			// 别问我为什么怎么写，有坑，不想看了
			setTimeout(function () {
				$("#scrollH").remove()
			},0)
			setTimeout(function () {
				$("#scrollH").remove()
			},0)
    },
    show_less_num: function(idOrClass,num){//字数限制方法，
        for(var i = 0; i < $(""+idOrClass+"").length; i++) {
            if($(""+idOrClass+"")[i].innerText.length > num) {
                $(""+idOrClass+"")[i].innerHTML = $(""+idOrClass+"")[i].innerText.substr(0,num)+"...";
            }
        }
    },
    wordfilter:function(){//敏感词过滤
        $("input.wordfilter").on("blur",function(){
            var _str = $(this).val();
            var result = _str.diyFilter();
            if(_str.diyFilterArr().length>0) {
                var _diy_str=_str.diyFilterArr().join(",");
                alert("字段中含有不恰当的词语："+_diy_str+", 系统已自动为你修改!");
                $(this).val(result);
            }
        });
        $("textarea.wordfilter").on("blur",function(){
            var _str = $(this).val();
            var result = _str.diyFilter();
            if(_str.diyFilterArr().length>0) {
                var _diy_str=_str.diyFilterArr().join(",");
                alert("字段中含有不恰当的词语："+_diy_str+", 系统已自动为你修改!");
                $(this).val(result);
            }
        });
        var data ="";
        $.ajax({
            url: "/static/wordfilter/normal.config",
            type: "get",
            success: function (result) {
                data = result;
            }
        });
        String.prototype.diyFilter=function(arr){
            if(!arr){
                arr =data.split("|").filter(item => item !== '');
            }
            var _this=this;
            arr.forEach(function(a,b,c){
                var _reg=new RegExp(a,"g");
                _this=_this.replace(_reg,"***");
            });
            return _this;
        }
        String.prototype.diyFilterArr = function(arr) {//此方法返回过滤的词语数组
            if(!arr) {
                arr =data.split("|").filter(item => item !== '');
            }
            var _this=this;
            var _arrFilter = [];
            arr.forEach(function(a, b, c) {
                if(_this.indexOf(a)>-1) {
                    _arrFilter.push(a)
                }
            });
            return _arrFilter
        }
    },
	removeData: function(modal,files){
		$("#"+modal+"").find('input:not(.noClear)').val('');
		$("#"+modal+"").find('textarea').val('');
		$("#"+modal+"").find('select').val('0');
		$("#"+modal+"").find("#"+files+"").find("li").not("#li_upload").remove();
	},

	mask_on: function() { //自定义遮罩开启
		this.scrollH = document.body.scrollHeight;
		$("body").append('<div class="md_mask" id="md_mask"></div>');
		$("#md_mask").css("height", this.scrollH);
	},
	mask_off: function() { //自定义遮罩关闭
		$("#md_mask").remove();
	},
	confirm: function(text_head, text_info, callback_yes, callback_no) { //自定义确定取消框小
		this.scrollH = document.body.scrollHeight;
		$("body").append('<div class="md_tanchu_mask" id="md_tanchu_mask"></div>');
		$("body").append('<div class="md_tanchu_del" id="md_tanchu_del"><div class="mb_tanchu_head mb_color_green">' + text_head + '<img src="/assets/images/clo.png" class="right mb_hover mb_margint10 mb_marginr10" id="md_close"/></div><p style="margin-top:20px;">' + text_info + '</p><div class="mb_tanchu_res"><a class="md_tanchu_yes" id="md_tanchu_yes">确定</a><a class="md_tanchu_no" id="md_tanchu_no">取消</a></div></div>');
		$("#md_tanchu_mask").css("height", this.scrollH);
		$("#md_tanchu_del").css("left", (this.innerW - 400) / 2 + "px").css("top", "30px");
		$("#md_tanchu_yes").click(function() {
			if(callback_yes() == undefined) {
				$("#md_tanchu_mask").remove();
				$("#md_tanchu_del").remove();
			}
		});
		$("#md_tanchu_no").click(function() {
			callback_no();
			$("#md_tanchu_mask").remove();
			$("#md_tanchu_del").remove();
		});
		$("#md_close").click(function() {
			$("#md_tanchu_mask").remove();
			$("#md_tanchu_del").remove();
		});
	},
	confirmRevise: function(width, text_head, text_info, callback_yes, callback_no, callback_verify) { //物品审核弹框  批准，驳回，修改批准
		this.scrollH = document.body.scrollHeight;
		$("body").append('<div class="md_tanchu_mask" id="md_tanchu_mask"></div>');
		$("body").append('<div class="md_tanchu_del" id="md_tanchu_del"><div class="mb_tanchu_head mb_color_green" style="margin-bottom:15px;">' + text_head + '<img src="/assets/images/clo.png" class="right mb_hover mb_margint10 mb_marginr10" id="md_close"/></div><div style="width:90%;margin:20px auto;">' + text_info + '</div><div class="mb_tanchu_res"><a class="md_tanchu_yes" id="md_tanchu_yes">批准</a><a class="md_tanchu_no" id="md_tanchu_revise">修改批准</a><a class="md_tanchu_no mb_marginl40" id="md_tanchu_no">驳回</a></div></div>');
		$("#md_tanchu_del").css("width", width + "px");
		$("#md_tanchu_mask").css("height", this.scrollH);
		$("#md_tanchu_del").css("left", (this.innerW - $("#md_tanchu_del").width()) / 2 + "px").css("top", "30px");
		$("#md_tanchu_yes").click(function() {
			if(callback_yes() == undefined) {
				$("#md_tanchu_mask").remove();
				$("#md_tanchu_del").remove();
			}		})
		$("#md_tanchu_no").click(function() {
			if(callback_no() == undefined) {
				$("#md_tanchu_mask").remove();
				$("#md_tanchu_del").remove();
			};
		})
		$("#md_tanchu_revise").click(function() {
			if(callback_verify() == undefined) {
				$("#md_tanchu_mask").remove();
				$("#md_tanchu_del").remove();
			};
		})
		$("#md_close").click(function() {
			$("#md_tanchu_mask").remove();
			$("#md_tanchu_del").remove();
		})
	},

	confirmSelect: function(width, text_head, text_info, callback_yes, callback_no) { //自定义确定取消框大
		this.scrollH = document.body.scrollHeight;
		$("body").append('<div class="md_tanchu_mask" id="md_tanchu_mask"></div>');
		$("body").append('<div class="md_tanchu_del" id="md_tanchu_del"><div class="mb_tanchu_head mb_color_green" style="margin-bottom:15px;">' + text_head + '<img src="/assets/images/clo.png" class="right mb_hover mb_margint10 mb_marginr10" id="md_close"/></div><div style="width:90%;margin:0 auto;">' + text_info + '</div><div class="mb_tanchu_res"><a class="md_tanchu_yes" id="md_tanchu_yes">确定</a><a class="md_tanchu_no" id="md_tanchu_no">取消</a></div></div>');
		$("#md_tanchu_del").css("width", width + "px");
		$("#md_tanchu_mask").css("height", this.scrollH);
		$("#md_tanchu_del").css("left", (this.innerW - $("#md_tanchu_del").width()) / 2 + "px").css("top", "30px");
		$("#md_tanchu_yes").click(function() {
			if(callback_yes() == undefined) {
				$("#md_tanchu_mask").remove();
				$("#md_tanchu_del").remove();
			}
		})
		$("#md_tanchu_no").click(function() {
			callback_no();
			$("#md_tanchu_mask").remove();
			$("#md_tanchu_del").remove();
		})
		$("#md_close").click(function() {
			$("#md_tanchu_mask").remove();
			$("#md_tanchu_del").remove();
		});
	},
	getCookie:function(c_name){
		if (document.cookie.length>0){
		  	c_start=document.cookie.indexOf(c_name + "=")
		  	if (c_start!=-1){
		    	c_start=c_start + c_name.length+1
		    	c_end=document.cookie.indexOf(";",c_start)
		    if (c_end==-1) c_end=document.cookie.length
		    	return unescape(document.cookie.substring(c_start,c_end))
		    }
		}
		return ""
	},
	ajax: function(type, url, data, success_callback) {
		$.ajax({
		    type: type,
		    url: url,
			data: data,
			timeout: 10000,
			async: true,
			dataType:"json",
		    headers : { 'ujy-session':md.getCookie('ujy_session')},
		    success: function(res){
		    	if(!res.code){
		    		success_callback(res)
		    	}else{
		    		if(res.code == '20000'){
		    			showTips(res.msg);
		    			window.location.href='/login';
		    		}else if(res.code == '20004'){
		    			showTips(res.msg);
		    			window.location.href='/login';
		    		}else{
		    			showTips(res.msg);
		    		}
		    	}
		    },
		    error: function(xhr){
		    	if(xhr.responseJSON){
		    		if(xhr.responseJSON.code == '20006'){
		    			showTips(xhr.responseJSON.msg);
		    			window.location.href='/login';
		    		}else if(xhr.responseJSON.code == '20009'){
						showTips(xhr.responseJSON.msg);
						window.location.href='/login';
					}else{
						showTips(xhr.responseJSON.msg,2000,0);
						md.load_off();
		    		}
		    	}else{
					showTips('服务器错误:'+[xhr.status]+'')
					md.load_off();
		    	}
		    } ,
		    complete:function(XMLHttpRequest,textStatus){
	            if(textStatus=='timeout'){
	                var xmlhttp = window.XMLHttpRequest ? new window.XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHttp");
	                xmlhttp.abort();
					showTips('网络超时,请重试');
					md.load_off();
	    　　　　}
	        }
		});
	}
}
md.wordfilter();
//优化段落把换行符改为br,标签改为&lt或&gt
function filterBr(str) {
	return str.replace(/\n/g, "</br>").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/&lt;\/br&gt;/g, "</br>")
};
//去掉字符串前后空格
function Trim(str){
  	return str.replace(/(^\s*)|(\s*$)/g, "");
}

//获取url的id
function getUrl_id(){
	var str = window.location.pathname;
	var index = str.lastIndexOf('/');
	str  = str .substring(index + 1, str.length);
	var urlId = parseInt(str);
	return urlId;
}
//获取当前月
function getToday() {
	var dd = new Date();
	var y = dd.getFullYear();
	var m = dd.getMonth() + 1;
	if(m < 10) m = "0" + m;
	var d = dd.getDate();
	if(d < 10) d = "0" + d;
	return y + "" + m ;
}
//获取当前时间含时分秒
function getToday() {
	var myDate = new Date();
	var year = myDate.getFullYear();
	var month = (myDate.getMonth() + 1);
	var day = myDate.getDate();
	var my_hours=myDate.getHours();
	var my_minutes=myDate.getMinutes();
	var my_sec=myDate.getSeconds();
	if(month < 10) month = "0" + month;
	if(day < 10) day = "0" + day;
	if(my_hours < 10) my_hours = "0" + my_hours;
	if(my_minutes < 10) my_minutes = "0" + my_minutes;
	if(my_sec < 10) my_sec = "0" + my_sec;
	return year + '-' + month + "-" + day + " "+my_hours+":"+my_minutes+":"+my_sec+"";
}
//全局单选验证逻辑
function global_check_one(id,callback) {
	var $checked = $("#"+id+" tr td input:checked");
	if(($checked.length > 0) && ($checked.length <= 1)) { //判断是否有复选卡选中
		$id = $("#"+id+" tr td input:checked").parent().parent().attr("id");
		callback($id)
	} else if($checked.length > 1) {
		showTips('只能选中一项进行操作~');
	} else {
		showTips('请至少选中一项进行操作~');;
	}
}
//全局复选验证逻辑
function global_check_all(id,callback) {
	var $checked = $("#"+id+" tr td input:checked");
	if($checked.length > 0) { //判断是否有复选卡选中
		$ids = []; //清空数组
		for(var i = 0; i < $checked.length; i++) {
			$ids.push($checked[i].parentNode.parentNode.id);
		}
		callback($ids)
	} else {
		showTips('请至少选中一项进行操作~');
	}
}
//全选
function checkAll(id) {
	$("#" + id).click(function() {
		$("input[name='checkItem']:checkbox").prop("checked", this.checked);
	});
}
//限制管理员显示数量
function limit_adminNum(classname,num) {
	$("." + classname).each(function() {
		var str = $(this).text();
		var re = /[，, ]/g;
		if(re.test(str)) {
			var n = str.match(re).length+1;
			if(n > num) {
				arr = (str.split(",")).slice(0, num);
				str = arr.join(",");
				$(this).text(str).append("等");
			}
		}
	});
}
//禁用启用两图标切换方法//用法：对应的img上加个class isOpen即可
function mb_qiehuan(className) {
	$("."+className+"").css("cursor", "pointer");
	$("."+className+"").click(function() {
		var self = this;
		if($(self).attr("src") == "/assets/images/state-open.png") {
			$(self).attr("src", "/assets/images/state-close.png").parent().parent().children("td:last-child").css("position", "relative").children().css("color", "#c2c2c2").parent().append("<div class='shade' style='position: absolute;top: 0;left: 0;width: 100%;height: 100%;opacity: 0.0;'></div>");
		} else {
			$(self).attr("src", "/assets/images/state-open.png").parent().siblings().children(".shade").siblings().css("color", "#434343").parent().children(".shade").remove();
		}
	})
}
//家长侧边栏
function parents_nav_change_setting() {
	var $url = location.href;
	if($url.indexOf("/teacher/config") > -1) {
		$(".header_right").find(".setting").parent().addClass("parents_active");
	}
}
//提示框
function showTips(txt, time, status) {
	var htmlCon = '';
	if(txt != '') {
		if(status != 0 && status != undefined) {
			htmlCon = '<div class="tipsBox" style="width:220px;padding:10px;background-color:#4AAF33;border-radius:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;color:#fff;box-shadow:0 0 3px #ddd inset;-webkit-box-shadow: 0 0 3px #ddd inset;text-align:center;position:fixed;top:25%;left:50%;z-index:999999;margin-left:-120px;"><img src="/assets/images/ok.png" style="vertical-align: middle;margin-right:5px;" alt="OK，"/>' + txt + '</div>';
		} else {
			htmlCon = '<div class="tipsBox" style="width:220px;padding:10px;background-color:#D84C31;border-radius:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;color:#fff;box-shadow:0 0 3px #ddd inset;-webkit-box-shadow: 0 0 3px #ddd inset;text-align:center;position:fixed;top:25%;left:50%;z-index:999999;margin-left:-120px;"><img src="/assets/images/err.png" style="vertical-align: middle;margin-right:5px;" alt="Error，"/>' + txt + '</div>';
		}
		$('body').prepend(htmlCon);
		if(time == '' || time == undefined) {
			time = 1500;
		}
		setTimeout(function() {
			$('.tipsBox').remove();
		}, time);
	}
}
//全局单选验证逻辑
function global_check_one(id,callback) {
	var $checked = $("#"+id+" tr td input:checked");
	if(($checked.length > 0) && ($checked.length <= 1)) { //判断是否有复选卡选中
		$id = $("#"+id+" tr td input:checked").parent().parent().attr("id");
		callback()
	} else if($checked.length > 1) {
		showTips('只能选中一项进行操作~');
	} else {
		showTips('请至少选中一项进行操作~');;
	}
}
//全局复选验证逻辑
function global_check_all(id,callback) {
	var $checked = $("#"+id+" tr td input:checked");
	if($checked.length > 0) { //判断是否有复选卡选中
		$ids = []; //清空数组
		for(var i = 0; i < $checked.length; i++) {
			$ids.push($checked[i].parentNode.parentNode.id);
		}
		callback($ids)
	} else {
		showTips('请至少选中一项进行操作~');
	}
}
//全选 /id/classname
function check_all(id,classname){
	$("#"+id+"").click(function() {
	if(!this.checked) {
		$("."+classname+"").each(function() {
			$(this).prop("checked", false);
		})
	}else{
		$("."+classname+"").each(function() {
		$(this).prop("checked", true);
	})
	}
});
$("."+classname+"").click(function(){
	var $len=$("."+classname+"").length;
	var $len_checked=$("."+classname+":checked").length;
	  if($len>$len_checked){
	  	$("#"+id+"").prop("checked", false);
	  }else{
	  	 $("#"+id+"").prop("checked", true);
	  }
  })
}

var module_type = {message:'/communicate/message/',document:'/communicate/document/',transfer:'/v2/teacher.html#/home/module/transfer',vote:'/communicate/vote/',vehicle:'/plan/vehicle/',place:'/plan/place/',repair:'/plan/repair/',trip:'/plan/trip/',vocation:'/plan/vocation/',material:'/plan/material/'};
var module_name = {message:'内部通知',document:'批办文件',transfer:'局校公文',vote:'投票调查',vehicle:'用车申请',place:'室场申请',repair:'报修申请',trip:'外出申请',vocation:'请假申请',material:'物品申请'};
//消息提醒、短轮询
var news_tips = {
	updata:function(){
		var _self=this;
		$.ajax({
			type: "GET",
			url: "/receivemessage",
			async: true,
			dataType: "json",
			success: function(res) {
				var _sum=0;
				res.forEach(function (num,index) {
					_sum+=parseInt(num.number);
				});
				if(_sum == 0){
					$("#news_tips_info").append('<li style="text-align:center;">暂无未读信息  </li>');
				}else if(_sum > 99){
						$("#notice_tips .notice_nums").addClass("notice_num");
						$("#notice_tips .notice_nums").text("99+");
						$("#news_tips_info").empty();
					res.forEach(function (num,index) {
						if (num.number!=0) {
							var each_module_name = num.module_type;
							$("#news_tips_info").append('<li data-type="'+num.module_type+'" module-manager="'+num.is_manager+'"><span class="mb_color_blue">['+module_name[each_module_name]+']</span>&nbsp;  有<span>'+num.number+'</span>条未读信息  </li>');
						}
					})
				}else{
					$("#notice_tips .notice_nums").addClass("notice_num");
					$("#notice_tips .notice_nums").text(_sum);
					$("#news_tips_info").empty();
					res.forEach(function (num,index) {
						if (num.number!=0) {
							var each_module_name = num.module_type;
							$("#news_tips_info").append('<li data-type="'+num.module_type+'" module-manager="'+num.is_manager+'"><span class="mb_color_blue">['+module_name[each_module_name]+']</span>&nbsp;  有<span>'+num.number+'</span>条未读信息  </li>');
						}
					})
				}
				_self.clk2();
				_self.clk3();
			}
		});
	},
	clk1: function() {
		$("#notice_tips").mouseenter(function() {
			// $(this).css("background-color","#42CD72");
			$("#news_tips_info").show();
		})
	},
	clk2:function () {
		$("#news_tips_info").mouseleave(function() {
			$(this).hide();
			// $("#notice_tips").css("background-color","#2BBB59");
		})
		$("#notice_tips").mouseleave(function() {
			$("#news_tips_info").hide();
			// $("#notice_tips").css("background-color","#2BBB59");
		})
	},
	clk3:function () {
		$("#news_tips_info li").click(function() {
			var data_type = $(this).attr("data-type");
			var manager = $(this).attr("module-manager");
			var a = ['message','document','transfer','vote'];
			window.open(module_type[data_type]+((manager==1&&$.inArray(data_type,a)==-1)?'manage':(manager==1&&data_type=='vote')?'all':''));
			$(this).remove();
		})
	}
}
 var auth_role = '<?php echo $this->auth_role;?>';
if (auth_role == 'teacher'||auth_role == 'officer') {
	news_tips.clk1()
	news_tips.clk2()
	news_tips.clk3()
	// news_tips.updata();
}
//公共tab
function parents_nav_change(href, text) {
	var $url = location.href;
	if($url.indexOf(href) > -1) {
		$(".nav-item:contains(" + text + ")").addClass("parents_active");
	}
}

/**
 * 截取图片名字
 */
function cutImgName(imgStr){
	var index = imgStr.lastIndexOf("\/");
	var new_imgStr  = imgStr .substring(index + 1, imgStr.length);
	return new_imgStr
}
parents_nav_change("/CloudScreen", "云屏应用");
parents_nav_change("/center/board", "云屏应用");
parents_nav_change("/center/index", "校园应用");
parents_nav_change("/communicate", "校园应用");
parents_nav_change("/plan", "校园应用");
// parents_nav_change("/teach", "教学&班牌");
// parents_nav_change("/teacher", "教学&班牌");
// parents_nav_change("/student", "教学&班牌");
// parents_nav_change("/exam", "教学&班牌");
parents_nav_change("/teach", "班级应用");
parents_nav_change("/teacher", "班级应用");
parents_nav_change("/student", "班级应用");
parents_nav_change("/exam", "班级应用");
parents_nav_change("/website", "官网应用");
parents_nav_change("/web", "官网应用");
parents_nav_change("/manager", "管理配置");

//
// function qx(){
// 	var $url = location.href;
// 	var module=''
// 	var transfer="/communicate/transfer"
// 	if($url.indexOf(transfer)>=0){
//     	$(".admin_limit").text("123");
//     	module=="transfer"
// 　　}
// 	md.ajax('post',http_url+'',{'module':module},function(res){

// 	})
// }
// qx();


function CloudScreen(){
	// 获取id
	var str = window.location.href;
	var index1 = str.lastIndexOf('?');
	str  = str .substring(index1 + 1, str.length);
	var urlId = parseInt(str);
	// 获取tag
	var type = window.location.href;
	var index = type.lastIndexOf('/');
	type = type.substring(index + 1, type.length).split("?")[0];
	var action = $("#news-form").attr("action");
	var myform = $("#myform").attr("action");
	if(type.indexOf("class") != -1 || type.indexOf("walk") != -1 || type.indexOf("place") != -1 || type.indexOf("nest") != -1 || type.indexOf("door") != -1 || type.indexOf("bus") != -1 || type.indexOf("member") != -1 || type.indexOf("vacation") != -1 || type.indexOf("vacation") != -1 || type.indexOf("all") != -1|| type.indexOf("visitor") != -1|| type.indexOf("meeting") != -1|| type.indexOf("canteen") != -1|| type.indexOf("wisdom") != -1|| type.indexOf("public") != -1|| type.indexOf("gym") != -1){
		// tab
		$(".mb_head .tag_info").each(function(){
			var href = $(this).attr("href");
			$(this).attr("href",href+'/'+type);
		});
		$(".tag_box .tag_info").each(function(){
			var href = $(this).attr("href");
			$(this).attr("href",href+'/'+type);
		});
		$(".tag_box .tag_info1").each(function(){
			var herf1 = $(this).attr("href")
			var date_id = $(this).attr("data-id");
			$(this).attr("href","")
			$(this).attr("href",herf1+'/'+type+'?'+ date_id);
		});
		$(".tag_box .event_detail").each(function(){
			var herf = $(this).attr("href")
			var date_id = $(this).attr("data-id");
			$(this).attr("href","")
			$(this).attr("href",herf + '/' +type+ '?' + date_id);
		});
		$("#edit_event").attr("href","/CloudScreen/event_edit/"+type+'?'+urlId);//通知详情页的编辑跳转
		$(".yp").attr("href","/iframe/screen/screen_"+type+"");
		// 表单提交的action
		$("#news-form").attr("action",action+'/'+type);
		$("#myform").attr("action",myform+'/'+type);
	}
	$("#folderManage").hide();
	if(type=="class" || type.indexOf("class") != -1){
		$(".tag_title").text("智慧班级屏");
		$(".xz_class").show();
		$(".cloud_manage").hide();
		$(".visitor").hide()
		$(".fk").hide()
	}else if(type=="walk"){
		$(".tag_title").text("选课走班屏幕");
		$(".walk").show()
	}else if(type=="place"){
		$(".tag_title").text("室场使用屏");
		$(".place").show()
	}else if(type=="nest"){
		$(".tag_title").text("宿舍考勤屏");
		$(".nest").show()
	}else if(type=="door"){
		$(".tag_title").text("校门考勤屏");
		$(".door").show()
	}else if(type=="bus"){
		$(".tag_title").text("校车考勤屏");
		$(".bus").show()
	}else if(type=="member"){
		$(".tag_title").text("人员去向屏");
		$(".member").show()
	}else if(type=="vacation"){
		$(".tag_title").text("学生请假屏");
		$(".vacation").show()
	}else if(type=="visitor"){
		$(".tag_title").text("访客登记屏");
		$(".visitor").show()
		$(".fk").show()
	}else if(type=="meeting"){
		$(".tag_title").text("会议签到屏");
		$(".hy").show()
	}else if(type=="canteen"){
		$(".tag_title").text("食堂消费屏");
	}else if(type=="wisdom"){
		$(".tag_title").text("智慧物联屏");
	}else if(type=="public"){
		$(".tag_title").text("公共区域展示屏");
		$(".mtbf").show();
	}else if(type=="gym"){
		$(".tag_title").text("场馆开放");
		$(".gym").show()
		$(".yp").hide()
	}else if(type=="all" || type.indexOf("all") != -1){
		$("#folderManage").show();
		$(".cloud_manage").show();
		$(".cloud_manage").show();
		$(".xz_class").hide();
		$(".visitor").hide()
		$(".fk").hide()
		$(".yp").hide()
	}
}
