/* 封装提示框*/
function showTips(txt,time,status)
{
	var htmlCon = '';
	if(txt != ''){
		if(status != 0 && status != undefined){
			htmlCon = '<div class="tipsBox" style="width:220px;padding:10px;background-color:#4AAF33;border-radius:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;color:#fff;box-shadow:0 0 3px #ddd inset;-webkit-box-shadow: 0 0 3px #ddd inset;text-align:center;position:fixed;top:25%;left:50%;z-index:999999;margin-left:-120px;"><img src="/assets/images/ok.png" style="vertical-align: middle;margin-right:5px;" alt="OK，"/>'+txt+'</div>';
		}else{
			htmlCon = '<div class="tipsBox" style="width:220px;padding:10px;background-color:#D84C31;border-radius:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;color:#fff;box-shadow:0 0 3px #ddd inset;-webkit-box-shadow: 0 0 3px #ddd inset;text-align:center;position:fixed;top:25%;left:50%;z-index:999999;margin-left:-120px;"><img src="/assets/images/err.png" style="vertical-align: middle;margin-right:5px;" alt="Error，"/>'+txt+'</div>';
		}
		$('body').prepend(htmlCon);
		if(time == '' || time == undefined){
			time = 1500;
		}
		setTimeout(function(){ $('.tipsBox').remove(); },time);
	}
}
$(".us_name").blur(function(){
var $us_name=$(".us_name").val();
     $.ajax({
        url: "/auth/change_username",
        type: "post",
        data: {
            'mobile':$us_name,
        },
        dataType: "json",
        success: function (result) {
            if (result.status==1) {
               
            } else {
                showTips(result.msg);
            }
        }
    });
});
var InterValObj; //timer变量，控制时间
var count = 30; //间隔函数，1秒执行
var curCount;//当前剩余秒数
var code = ""; //验证码
var codeLength = 6;//验证码长度
//发送短信
function sendMessage() {
    var $us_name=$(".us_name").val();
    var $codeId = $("#codeInput").attr('data-codeId');
    var $codeStr = $("#codeInput").val();
    if($us_name==''){
        showTips("请输入手机号!");  
        return false; 
    } else if(!(/^1[3456789]\d{9}$/.test($us_name))) {
        showTips('请输入正确的手机号码~');
        return false;
    } else if( !$codeStr && !$codeId){
        showTips('请输入正确验证码~');
        return false;
    }else {
        //向后台发送处理数据
        $.ajax({
            url: "/sms/send",
            type: "post",
            data: {
                'mobile':$us_name,
                'type':'forget',
                'code_id':$codeId, 
                'code':$codeStr
            },
            dataType: "json",
            success: function (result) {
                if (result.status==1) {
                    showTips('发送成功', 1000, 1);
                    curCount = count;
                    //设置button效果，开始计时
                    $("#btnSendCode").css({"background-color":"#dcdcdc","color":"#000"});
                    $("#btnSendCode").attr("disabled", "true");
                    $("#btnSendCode").val( + curCount + "秒再获取");
                    InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
                } else {
                    showTips(result.msg);
                }
            }
        });
    }
}

/**
 * 图片验证码
 */
function imgCode(){
    $.ajax({
        url: http_url+"/captcha",
        type: "get",
        dataType: "json",
        success: function (res) {
            var code = res.content;
            $("#imgCode").attr('src',code)
            $("#codeInput").attr('data-codeId',res.id)
        }
    });
}
//timer处理函数
function SetRemainTime() {
    if (curCount == 0) {                
        window.clearInterval(InterValObj);//停止计时器
        $("#btnSendCode").css({"background-color":"#ffb22b","color":"#fff"});
        $("#btnSendCode").removeAttr("disabled");//启用按钮
        $("#btnSendCode").val("重获验证码");
        code = ""; //清除验证码。如果不清除，过时间后，输入收到的验证码依然有效    
    }
    else {
        curCount--;
        $("#btnSendCode").val( + curCount + "秒再获取");
    }
}

//密码强度验证
$(function(){ 
	$('#pass').keyup(function () { 
		var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g"); 
		var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g"); 
		var enoughRegex = new RegExp("(?=.{6,}).*", "g"); 
	
		if (false == enoughRegex.test($(this).val())) { 
			$('#level').removeClass('pw-weak'); 
			$('#level').removeClass('pw-medium'); 
			$('#level').removeClass('pw-strong'); 
			$('#level').addClass(' pw-defule'); 
			 //密码小于六位的时候，密码强度图片都为灰色 
		} 
		else if (strongRegex.test($(this).val())) { 
			$('#level').removeClass('pw-weak'); 
			$('#level').removeClass('pw-medium'); 
			$('#level').removeClass('pw-strong'); 
			$('#level').addClass(' pw-strong'); 
			 //密码为八位及以上并且字母数字特殊字符三项都包括,强度最强 
		} 
		else if (mediumRegex.test($(this).val())) { 
			$('#level').removeClass('pw-weak'); 
			$('#level').removeClass('pw-medium'); 
			$('#level').removeClass('pw-strong'); 
			$('#level').addClass(' pw-medium'); 
			 //密码为七位及以上并且字母、数字、特殊字符三项中有两项，强度是中等 
		} 
		else { 
			$('#level').removeClass('pw-weak'); 
			$('#level').removeClass('pw-medium'); 
			$('#level').removeClass('pw-strong'); 
			$('#level').addClass('pw-weak'); 
			 //如果密码为6为及以下，就算字母、数字、特殊字符三项都包括，强度也是弱的 
		} 
		return true; 
	}); 
}) 
//jQuery time
var current_fs, next_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches


//下一步
$("#admin_step1").click(function(){
    var $this = $(this);
    var $us_name=$(".us_name").val();
    var $us_code=$(".us_code").val();
    if($us_name==''){
        showTips("请输入手机号!");  
        return false; 
    } else if(!(/^1[3456789]\d{9}$/.test($us_name))){ 
        showTips("请输入正确的手机号码!");  
        return false; 
    }  else if($us_code==''){
        showTips("请输入验证码!");  
        return false; 
    }else{
            $.ajax({
            type: "POST",
            url: "auth/ajax_forget",
            data: {'mobile':$us_name,'code':$us_code},
            dataType:'json',
            async: true,
            success: function (result){ 
                if(result.status == 1){
                    showTips('验证成功', 1000, 1);
                    if(animating) return false;
                    animating = true;
                    
                    current_fs = $this.parent().parent().parent();
                    next_fs = $this.parent().parent().parent().next();
                    
                    //show the next fieldset
                    next_fs.show(); 
                    //hide the current fieldset with style
                    current_fs.animate({opacity: 0}, {
                        step: function(now, mx) {
                            //as the opacity of current_fs reduces to 0 - stored in "now"
                            //1. scale current_fs down to 80%
                            scale = 1 - (1 - now) * 0.2;
                            //2. bring next_fs from the right(50%)
                            left = (now * 50)+"%";
                            //3. increase opacity of next_fs to 1 as it moves in
                            opacity = 1 - now;
                            current_fs.css({'transform': 'scale('+scale+')'});
                            next_fs.css({'left': left, 'opacity': opacity});
                        }, 
                        duration: 800, 
                        complete: function(){
                            current_fs.hide();
                            animating = false;
                        }, 
                        //this comes from the custom easing plugin
                        easing: 'easeInOutBack'
                    });

                } else {
                    showTips(result.msg);
                }
            }
        });
    }
});

$("#admin_step2").click(function(){
    var $this = $(this); 
    var enoughRegex = new RegExp("(?=.{6,}).*", "g");//验证规则
    var $new_password = $('input[name="new_password"]').val();
    var $confirm_password = $('input[name="confirm_password"]').val();
    var $us_name=$(".us_name").val();
    var $us_code=$(".us_code").val();
    if($new_password != $confirm_password){
        showTips("两次输入密码不一致");
        return;
    }
    if(!enoughRegex.test($new_password)){
        showTips("您的密码不能低于6位且不能含有非法字符");
        return;
    }
    var $us_name = $(".us_name").val();

    $.ajax({
        type:"post",
        url:"auth/forget_password",
        async:true,
        data:{
            'new_password':$new_password,
            'mobile':$us_name,
            'code':$us_code
        },
        dataType:'json',
        success:function(result) {
            if (result.status == 1) {
                showTips('密码修改成功~',1000,1);
                if(animating) return false;
                    animating = true;
                    
                    current_fs = $this.parent().parent().parent();
                    next_fs = $this.parent().parent().parent().next();
                    
                    //show the next fieldset
                    next_fs.show(); 
                    //hide the current fieldset with style
                    current_fs.animate({opacity: 0}, {
                        step: function(now, mx) {
                            //as the opacity of current_fs reduces to 0 - stored in "now"
                            //1. scale current_fs down to 80%
                            scale = 1 - (1 - now) * 0.2;
                            //2. bring next_fs from the right(50%)
                            left = (now * 50)+"%";
                            //3. increase opacity of next_fs to 1 as it moves in
                            opacity = 1 - now;
                            current_fs.css({'transform': 'scale('+scale+')'});
                            next_fs.css({'left': left, 'opacity': opacity});
                        }, 
                        duration: 800, 
                        complete: function(){
                            current_fs.hide();
                            animating = false;
                        }, 
                        //this comes from the custom easing plugin
                        easing: 'easeInOutBack'
                    });

            } else {
                showTips(result.msg);
            }
        }
    });
})